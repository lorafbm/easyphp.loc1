<?php

$_SESSION['pages'] .= $_SERVER['PHP_SELF']. "|";