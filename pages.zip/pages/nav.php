<ul>
        <li><a href="page1.php">Страница 1</a></li>
        <li><a href="page2.php">Страница 2</a></li>
        <li><a href="page3.php">Страница 3</a></li>
        <li><a href="page4.php">Страница 4</a></li>
</ul>